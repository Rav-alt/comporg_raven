#include <stdio.h>
void secret() { printf("Hacked!\n"); }
int main() {
  char buf[64];
  gets(buf);
  printf("You entered: %s\n", buf);
  return 0;
}
