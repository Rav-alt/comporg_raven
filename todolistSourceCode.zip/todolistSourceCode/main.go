package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

var todoList []string

func main() {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Println("\nTo-Do SHIT")
		fmt.Println("1. Add Task")
		fmt.Println("2. View Tasks")
		fmt.Println("3. Remove Task")
		fmt.Println("4. Exit")
		fmt.Print("Choose an option: ")

		choice, _ := reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		switch choice {
		case "1":
			addTask(reader)
		case "2":
			viewTasks()
		case "3":
			removeTask(reader)
		case "4":
			fmt.Println("Exiting... Goodbye!")
			return
		default:
			fmt.Println("Invalid option. Please try again.")
		}
	}
}

func addTask(reader *bufio.Reader) {
	fmt.Print("Enter the task: ")
	task, _ := reader.ReadString('\n')
	task = strings.TrimSpace(task)
	todoList = append(todoList, task)
	fmt.Println("Task added!")
}

func viewTasks() {
	if len(todoList) == 0 {
		fmt.Println("No tasks in the list.")
		return
	}

	fmt.Println("\nYour To-Do List:")
	for i, task := range todoList {
		fmt.Printf("%d. %s\n", i+1, task)
	}
}

func removeTask(reader *bufio.Reader) {
	if len(todoList) == 0 {
		fmt.Println("No tasks to remove.")
		return
	}

	viewTasks()
	fmt.Print("Enter the task number to remove: ")
	var taskNumber int
	_, err := fmt.Scanf("%d", &taskNumber)

	if err != nil || taskNumber < 1 || taskNumber > len(todoList) {
		fmt.Println("Invalid task number.")
		return
	}

	todoList = append(todoList[:taskNumber-1], todoList[taskNumber:]...)
	fmt.Println("Task removed!")
}
